class Manager:
  """
  Represents a manager with a name and password.
  """
  
  def __init__(self, name_of_owner, password):
    self.name_of_owner = name_of_owner
    self.password = password
